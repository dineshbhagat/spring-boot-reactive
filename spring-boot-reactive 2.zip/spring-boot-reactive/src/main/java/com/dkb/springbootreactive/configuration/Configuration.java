package com.dkb.springbootreactive.configuration;

import org.springframework.boot.SpringBootConfiguration;

@SpringBootConfiguration
public class Configuration {
}
